import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import io from "socket.io-client";
import Button from "react-bootstrap/Button";
const socket = io("http://localhost:3001", { transports: ["websocket"] });

function Create() {
  const [state, setState] = useState({
    id: "",
    pw: "",
    pw_check: "",
    name: "",
    phone: "",
    SSN: "",
    email: "",
    Duplicate: 0,
  });

  const navigate = useNavigate();

  function navigateToBack() {
    navigate("/");
  }

  function handleChange(e: any) {
    setState({
      ...state,
      [e.target.name]: e.target.value,
    });
  }

  function Send_Duplicate() {
    return new Promise((resolve, reject) => {
      socket.emit("Send Duplicate Check", {
        id: state.id,
      });
      setState({
        ...state,
        id: "",
      });
      resolve(0);
    });
  }

  function Rec_Duplicate() {
    return new Promise((resolve, reject) => {
      socket.on("Receive Duplicate Check", (message) => {
        resolve(message.Duplicate);
      });
    });
  }

  async function Duplicate_check() {
    if (state.id === "") {
      alert("아이디를 입력해주세요.");
    } else {
      await Send_Duplicate();
      var Duplicate = await Rec_Duplicate();

      if (Duplicate === 2) {
        alert("아이디가 중복됩니다.");
      } else if (Duplicate === 1) {
        alert("사용가능한 아이디입니다.");
      } else {
        alert("관리지에게 문의하세요.");
      }
    }
  }

  function user_update() {
    socket.disconnect();
  }

  return (
    <div className="box">
      <form className="create_form">
        <fieldset className="inner_form">
          <legend className="title">회원가입</legend>
          <div className="id_title">
            <span className="subtitle1">아이디 : </span>
            <div className="id_section">
              <input
                type="text"
                name="id"
                className="id"
                value={state.id}
                placeholder="아이디를 입력해주세요"
                onChange={handleChange}
              ></input>
              <button
                className="id_check_btn"
                name="data"
                type="button"
                onClick={Duplicate_check}
              >
                중복
              </button>
            </div>
          </div>
          <div>
            <span className="subtitle">비밀번호 : </span>
            <input
              type="password"
              name="pw"
              className="pw"
              value={state.pw}
              placeholder="비밀번호를 입력해주세요"
              onChange={handleChange}
            ></input>
          </div>
          <div>
            <span className="subtitle">비밀번호 확인 : </span>
            <input
              type="password"
              name="pw_check"
              className="pw"
              value={state.pw_check}
              placeholder="비밀번호를 입력해주세요"
              onChange={handleChange}
            ></input>
          </div>
          <div>
            <span className="subtitle1">이름 : </span>
            <input
              type="text"
              name="name"
              className="name"
              value={state.name}
              placeholder="이름을 입력해주세요"
              onChange={handleChange}
            ></input>
          </div>
          <div>
            <span className="subtitle">전화번호 : </span>
            <input
              type="text"
              name="phone"
              className="phone"
              value={state.phone}
              placeholder="전화번호를 입력해주세요"
              onChange={handleChange}
            ></input>
          </div>
          <div>
            <span className="subtitle">주민번호 : </span>
            <input
              type="text"
              name="SSN"
              className="SSN"
              value={state.SSN}
              placeholder="주민번호를 입력해주세요"
              onChange={handleChange}
            ></input>
          </div>
          <div>
            <span className="subtitle">e-mail : </span>
            <input
              type="text"
              name="email"
              className="email"
              value={state.email}
              placeholder="이메일을 입력해주세요"
              onChange={handleChange}
            ></input>
          </div>
        </fieldset>
        <button type="button" className="create_btn" onClick={user_update}>
          확인
        </button>
      </form>
    </div>
  );
}

export default Create;
