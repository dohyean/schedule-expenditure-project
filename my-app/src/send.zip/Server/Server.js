// 서버
const express = require("express");
const app = express();
const port = 3001;
const http = require("http").createServer(app);
const io = require("socket.io")(http, { cors: { origin: "*" } });
const Open_dbms = require("./Sql/Function/Tmp_page/Open_dbms.js");
const Close_dbms = require("./Sql/Function/Tmp_page/Close_dbms.js");

const Duplicate_check = require("./Sql/Function/Create_page/Dpulicate_check.js");

http.listen(port, () => {
  console.log(`app listening on port : ${port}`);
});

async function fun_Duplicate_check(db, io, item) {
  await Duplicate_check.duplicate_chck(db, io, item.id);
}

io.on("connection", (socket) => {
  const db = Open_dbms.open_dbms();

  socket.on("Send Duplicate Check", (item) => {
    fun_Duplicate_check(db, io, item, socket);
  });

  socket.on("disconnect", function () {
    Close_dbms.close_dbms(db);
  });
});
